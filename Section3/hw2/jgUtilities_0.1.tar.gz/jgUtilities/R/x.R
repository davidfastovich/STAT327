#' This Is A One-line Title Describing x
#'
#' This is the Description paragraph. x is my favorite data set. Blah, blah,
#' blah.
#'
#' @format x is a data frame with 3 rows and 2 variables:
#' \describe{
#'   \item{h}{height (inches)}
#'   \item{w}{weight (pounds)}
#' }
#' @source
#' These data are from an experiment I did with my friend William
#' (\url{http://en.wikipedia.org/wiki/William_Sealy_Gosset}) 
#' at the Guiness Brewery in Dublin in 1908.
"x"
